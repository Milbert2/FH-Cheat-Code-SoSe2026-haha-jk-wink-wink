<?php
    if ($_SERVER['HTTP_HOST'] == 'users.ct.fh-salzburg.ac.at') {
        $DB_NAME = "leaderboard";
        $DB_USER = "db1_reader";
        $DB_PASS = "geheim!";
        $DSN     = "pgsql:dbname=$DB_NAME;host=localhost";
    } else {
        $DB_NAME = "hotel_db";
        $DB_USER = "postgres"; // fill in your local db username here!!
        $DB_PASS = "1234"; // fill in your locals db password here!!
        $DSN     = "pgsql:dbname=$DB_NAME;host=localhost";
    }
?>
